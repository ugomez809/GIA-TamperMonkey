# SDR Ricochet Browser Setup V1
# Run as Administrator.
# Creates a dedicated Chrome profile, force-installs Tampermonkey, applies Ricochet site permissions, creates shortcut, and opens final setup pages.

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---------------- CONFIG ----------------
$ProfileName = 'SDR Ricochet'
$ShortcutName = 'SDR Browser'
$RicochetUrl = 'https://giainc.ricochet.me/login'
$RicochetPattern = 'https://giainc.ricochet.me'
$TampermonkeyId = 'dhdgffkkebhmkfjojejmpbldmpobfkfo'
$TampermonkeyUpdateUrl = 'https://clients2.google.com/service/update2/crx'
$UserScriptInstallUrls = @(
    'https://raw.githubusercontent.com/ugomez809/GIA-TamperMonkey/main/Ricochet/Pickup%20%26%20Hangup%20Counters/ricochet-pickup-hangup-counters-updater.user.js',
    'https://raw.githubusercontent.com/ugomez809/GIA-TamperMonkey/main/Ricochet/Voicemail%20Lead%20Watcher/ricochet-voicemail-lead-watcher-updater.user.js'
)

$BaseRoot = 'C:\SDR_Ricochet'
$ChromeUserDataDir = Join-Path $BaseRoot 'ChromeUserData'
$ChromeProfileDir = 'SDR Ricochet'
$ChromeProfilePath = Join-Path $ChromeUserDataDir $ChromeProfileDir
$LogPath = Join-Path $BaseRoot 'setup.log'
$PayloadRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$ChecklistPath = Join-Path $PayloadRoot 'final-checklist.html'
$LocalScriptPaths = @(
    (Join-Path $PayloadRoot 'scripts\ricochet-pickup-hangup-counters-updater.user.js'),
    (Join-Path $PayloadRoot 'scripts\ricochet-voicemail-lead-watcher-updater.user.js')
)

# ---------------- HELPERS ----------------
function Write-SetupLog {
    param([string]$Message)
    $line = "{0}  {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Write-Host $line
    Add-Content -Path $LogPath -Value $line -Encoding UTF8
}

function Assert-Admin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'This setup must be run as Administrator.'
    }
}

function Ensure-Folder {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Get-ChromePath {
    $candidates = @()

    try {
        $appKey = Get-Item -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe' -ErrorAction SilentlyContinue
        if ($appKey) {
            $appPath = $appKey.GetValue('')
            if ($appPath) { $candidates += $appPath }
        }
    } catch {}

    $candidates += @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) { return $candidate }
    }

    return $null
}

function Install-ChromeIfMissing {
    $chrome = Get-ChromePath
    if ($chrome) {
        Write-SetupLog "Chrome found: $chrome"
        return $chrome
    }

    Write-SetupLog 'Chrome not found. Trying winget install...'
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if ($winget) {
        try {
            $p = Start-Process -FilePath $winget.Source -ArgumentList @(
                'install', '--id', 'Google.Chrome', '-e', '--silent',
                '--accept-package-agreements', '--accept-source-agreements'
            ) -Wait -PassThru -WindowStyle Hidden
            Write-SetupLog "winget exit code: $($p.ExitCode)"
        } catch {
            Write-SetupLog "winget install failed: $($_.Exception.Message)"
        }
    } else {
        Write-SetupLog 'winget not found.'
    }

    $chrome = Get-ChromePath
    if ($chrome) { return $chrome }

    Write-SetupLog 'Trying direct Google Chrome installer download...'
    $installer = Join-Path $env:TEMP 'ChromeSetup.exe'
    Invoke-WebRequest -Uri 'https://dl.google.com/chrome/install/latest/chrome_installer.exe' -OutFile $installer -UseBasicParsing
    $p2 = Start-Process -FilePath $installer -ArgumentList '/silent', '/install' -Wait -PassThru
    Write-SetupLog "Chrome direct installer exit code: $($p2.ExitCode)"

    $chrome = Get-ChromePath
    if (-not $chrome) { throw 'Chrome install finished, but chrome.exe was not found.' }
    return $chrome
}

function Add-PolicyListValue {
    param(
        [string]$PolicyName,
        [string[]]$Values
    )

    $key = "HKLM:\SOFTWARE\Policies\Google\Chrome\$PolicyName"
    Ensure-FolderRegistry -Path $key

    $existing = @{}
    try {
        $props = Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
        if ($props) {
            foreach ($p in $props.PSObject.Properties) {
                if ($p.Name -match '^\d+$' -and $p.Value) {
                    $existing[[string]$p.Value] = $true
                }
            }
        }
    } catch {}

    $next = 1
    try {
        $names = (Get-ItemProperty -Path $key -ErrorAction SilentlyContinue).PSObject.Properties.Name | Where-Object { $_ -match '^\d+$' } | ForEach-Object { [int]$_ }
        if ($names) { $next = (($names | Measure-Object -Maximum).Maximum + 1) }
    } catch {}

    foreach ($value in $Values) {
        if (-not $existing.ContainsKey($value)) {
            New-ItemProperty -Path $key -Name ([string]$next) -PropertyType String -Value $value -Force | Out-Null
            Write-SetupLog "Policy added: $PolicyName [$next] = $value"
            $existing[$value] = $true
            $next++
        } else {
            Write-SetupLog "Policy already present: $PolicyName = $value"
        }
    }
}

function Ensure-FolderRegistry {
    param([string]$Path)
    if (-not (Test-Path -Path $Path)) {
        New-Item -Path $Path -Force | Out-Null
    }
}

function Set-ChromePolicies {
    Write-SetupLog 'Applying Chrome policies...'
    Ensure-FolderRegistry -Path 'HKLM:\SOFTWARE\Policies\Google\Chrome'

    Add-PolicyListValue -PolicyName 'ExtensionInstallForcelist' -Values @( "$TampermonkeyId;$TampermonkeyUpdateUrl" )

    # Site permissions for Ricochet.
    # These are URL allow-list policies, so they should not broadly allow other sites.
    Add-PolicyListValue -PolicyName 'AudioCaptureAllowedUrls' -Values @($RicochetPattern)
    Add-PolicyListValue -PolicyName 'NotificationsAllowedForUrls' -Values @($RicochetPattern)
    Add-PolicyListValue -PolicyName 'PopupsAllowedForUrls' -Values @($RicochetPattern)
    Add-PolicyListValue -PolicyName 'ClipboardAllowedForUrls' -Values @($RicochetPattern)
    Add-PolicyListValue -PolicyName 'JavaScriptAllowedForUrls' -Values @($RicochetPattern)

    # User asked to allow intrusive ads. Chrome exposes this as a browser-level policy, not per-site.
    # 1 = Allow ads on sites with intrusive ads. 2 = Block ads on sites with intrusive ads.
    New-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Google\Chrome' -Name 'AdsSettingForIntrusiveAdsSites' -PropertyType DWord -Value 1 -Force | Out-Null
    Write-SetupLog 'Policy set: AdsSettingForIntrusiveAdsSites = 1'
}

function Grant-ProfilePermissions {
    Write-SetupLog "Granting Users modify permission on $BaseRoot ..."
    & icacls $BaseRoot /grant 'Users:(OI)(CI)M' /T /C | Out-Null
}

function Convert-ToChromeTime {
    param([datetime]$Date)
    $epoch = [datetime]'1601-01-01T00:00:00Z'
    return [string][int64](($Date.ToUniversalTime() - $epoch).TotalSeconds * 1000000)
}

function Write-InitialProfileFiles {
    Ensure-Folder -Path $ChromeUserDataDir
    Ensure-Folder -Path $ChromeProfilePath

    $now = Convert-ToChromeTime -Date (Get-Date)

    $bookmarks = [ordered]@{
        checksum = ''
        roots = [ordered]@{
            bookmark_bar = [ordered]@{
                children = @(
                    [ordered]@{
                        date_added = $now
                        guid = ([guid]::NewGuid().ToString())
                        id = '10'
                        name = 'Ricochet Login'
                        type = 'url'
                        url = $RicochetUrl
                    }
                )
                date_added = $now
                date_modified = $now
                guid = '00000000-0000-4000-a000-000000000002'
                id = '1'
                name = 'Bookmarks bar'
                type = 'folder'
            }
            other = [ordered]@{
                children = @()
                date_added = $now
                date_modified = '0'
                guid = '00000000-0000-4000-a000-000000000003'
                id = '2'
                name = 'Other bookmarks'
                type = 'folder'
            }
            synced = [ordered]@{
                children = @()
                date_added = $now
                date_modified = '0'
                guid = '00000000-0000-4000-a000-000000000004'
                id = '3'
                name = 'Mobile bookmarks'
                type = 'folder'
            }
        }
        version = 1
    }

    $prefs = [ordered]@{
        bookmark_bar = [ordered]@{ show_on_all_tabs = $true }
        browser = [ordered]@{ check_default_browser = $false }
        distribution = [ordered]@{
            make_chrome_default = $false
            suppress_first_run_bubble = $true
            show_welcome_page = $false
            skip_first_run_ui = $true
        }
        profile = [ordered]@{ name = $ProfileName }
        session = [ordered]@{
            restore_on_startup = 4
            startup_urls = @($RicochetUrl)
        }
    }

    ($bookmarks | ConvertTo-Json -Depth 20) | Set-Content -Path (Join-Path $ChromeProfilePath 'Bookmarks') -Encoding UTF8
    ($prefs | ConvertTo-Json -Depth 20) | Set-Content -Path (Join-Path $ChromeProfilePath 'Preferences') -Encoding UTF8

    Write-SetupLog 'Initial Chrome profile files created.'
}

function New-DesktopShortcut {
    param([string]$ChromePath)

    $desktop = [Environment]::GetFolderPath('CommonDesktopDirectory')
    if (-not $desktop) { $desktop = [Environment]::GetFolderPath('Desktop') }

    $shortcutPath = Join-Path $desktop "$ShortcutName.lnk"
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $ChromePath
    $shortcut.Arguments = "--user-data-dir=`"$ChromeUserDataDir`" --profile-directory=`"$ChromeProfileDir`" --no-first-run --no-default-browser-check --new-window `"$RicochetUrl`""
    $shortcut.WorkingDirectory = Split-Path -Parent $ChromePath
    $shortcut.IconLocation = "$ChromePath,0"
    $shortcut.Description = 'Open SDR Ricochet Chrome profile'
    $shortcut.Save()

    Write-SetupLog "Desktop shortcut created: $shortcutPath"
}

function Open-FinalPages {
    param([string]$ChromePath)

    $baseArgs = @(
        "--user-data-dir=`"$ChromeUserDataDir`"",
        "--profile-directory=`"$ChromeProfileDir`"",
        '--no-first-run',
        '--no-default-browser-check'
    )

    Write-SetupLog 'Opening SDR Browser and final setup pages...'
    Start-Process -FilePath $ChromePath -ArgumentList ($baseArgs + @('--new-window', $RicochetUrl)) | Out-Null
    Start-Sleep -Seconds 6

    # Open Tampermonkey details page so the user can enable Allow User Scripts.
    Start-Process -FilePath $ChromePath -ArgumentList ($baseArgs + @("chrome://extensions/?id=$TampermonkeyId")) | Out-Null
    Start-Sleep -Seconds 2

    # Open online userscript installers. This avoids needing file:// access.
    foreach ($installUrl in $UserScriptInstallUrls) {
        Start-Process -FilePath $ChromePath -ArgumentList ($baseArgs + @($installUrl)) | Out-Null
        Start-Sleep -Seconds 1
    }

    if (Test-Path -LiteralPath $ChecklistPath) {
        Start-Process -FilePath $ChecklistPath | Out-Null
    }
}

# ---------------- MAIN ----------------
try {
    Assert-Admin
    Ensure-Folder -Path $BaseRoot
    '' | Set-Content -Path $LogPath -Encoding UTF8
    Write-SetupLog '===== SDR Ricochet setup started ====='

    foreach ($localScriptPath in $LocalScriptPaths) {
        if (Test-Path -LiteralPath $localScriptPath) {
            Write-SetupLog "Included userscript found: $localScriptPath"
        } else {
            Write-SetupLog "WARNING: Included userscript file not found: $localScriptPath. Online install URL will still be opened."
        }
    }

    foreach ($installUrl in $UserScriptInstallUrls) {
        Write-SetupLog "Userscript install URL: $installUrl"
    }

    $chromePath = Install-ChromeIfMissing
    Write-SetupLog "Using Chrome: $chromePath"

    Set-ChromePolicies
    Write-InitialProfileFiles
    Grant-ProfilePermissions
    New-DesktopShortcut -ChromePath $chromePath
    Open-FinalPages -ChromePath $chromePath

    Write-SetupLog '===== SDR Ricochet setup complete ====='
    Write-Host ''
    Write-Host 'Done. Finish the checklist window that opened.' -ForegroundColor Green
} catch {
    $msg = $_.Exception.Message
    try { Write-SetupLog "ERROR: $msg" } catch { Write-Host "ERROR: $msg" }
    Write-Host ''
    Write-Host "Setup failed: $msg" -ForegroundColor Red
    Write-Host "Log: $LogPath"
    pause
    exit 1
}
