SDR Ricochet Setup V1
======================

Goal
----
Build an installer EXE that prepares a Windows 11 PC for an SDR using Chrome + Tampermonkey + Ricochet.

Included
--------
- setup.ps1
- installer.iss
- final-checklist.html
- scripts\ricochet-pickup-hangup-counters-updater.user.js
- scripts\ricochet-voicemail-lead-watcher-updater.user.js

What setup.ps1 does
-------------------
1. Installs Chrome if missing.
2. Creates C:\SDR_Ricochet\ChromeUserData.
3. Creates a dedicated Chrome profile directory: SDR Ricochet.
4. Force-installs Tampermonkey through Chrome policy.
5. Allows Ricochet permissions through Chrome policy:
   - Microphone
   - Notifications
   - JavaScript
   - Pop-ups and redirects
   - Clipboard
   - Intrusive ads behavior
6. Creates desktop shortcut: SDR Browser.
7. Opens Ricochet, Tampermonkey details, both Ricochet updater userscript install URLs, and the checklist.

Manual steps left
-----------------
1. Enable Allow User Scripts on Tampermonkey.
2. Click Install on the Ricochet Pickup & Hangup Counters Updater tab.
3. Click Install on the Ricochet Voicemail Lead Watcher Updater tab.

Build EXE
---------
1. Install Inno Setup on the Windows PC.
2. Right-click BUILD_EXE.bat > Run as administrator, or open installer.iss in Inno Setup and click Compile.
3. The compiled EXE will be created in the Output folder.

Test without compiling
----------------------
Right-click RUN_SETUP_AS_ADMIN.bat > Run as administrator.
