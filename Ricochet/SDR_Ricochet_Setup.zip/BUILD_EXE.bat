@echo off
setlocal
cd /d "%~dp0"

echo Building SDR Ricochet installer...

set "ISCC1=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
set "ISCC2=%ProgramFiles%\Inno Setup 6\ISCC.exe"

if exist "%ISCC1%" (
  "%ISCC1%" "installer.iss"
  goto :done
)

if exist "%ISCC2%" (
  "%ISCC2%" "installer.iss"
  goto :done
)

echo.
echo Inno Setup compiler was not found.
echo Install Inno Setup, then run this again:
echo https://jrsoftware.org/isinfo.php
echo.
pause
exit /b 1

:done
echo.
echo Done. Check the Output folder.
pause
