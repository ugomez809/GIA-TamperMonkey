; SDR Ricochet Browser Setup V1
; Compile with Inno Setup Compiler on Windows.

#define MyAppName "SDR Ricochet Browser Setup"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "GIA INC"

[Setup]
AppId={{8E1A3863-6C8D-4F3F-9C98-5E982B0C4D8A}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\SDR Ricochet Browser Setup
DefaultGroupName=SDR Ricochet Browser Setup
DisableProgramGroupPage=yes
OutputDir=Output
OutputBaseFilename=SDR_Ricochet_Browser_Setup_V1
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesInstallIn64BitMode=x64compatible
SetupLogging=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Files]
Source: "setup.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "final-checklist.html"; DestDir: "{app}"; Flags: ignoreversion
Source: "README.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "scripts\ricochet-pickup-hangup-counters-updater.user.js"; DestDir: "{app}\scripts"; Flags: ignoreversion
Source: "scripts\ricochet-voicemail-lead-watcher-updater.user.js"; DestDir: "{app}\scripts"; Flags: ignoreversion

[Icons]
Name: "{group}\Final Checklist"; Filename: "{app}\final-checklist.html"
Name: "{group}\Read Me"; Filename: "{app}\README.txt"

[Run]
Filename: "powershell.exe"; Parameters: "-NoProfile -ExecutionPolicy Bypass -File ""{app}\setup.ps1"""; WorkingDir: "{app}"; Flags: runhidden waituntilterminated
Filename: "{app}\final-checklist.html"; Description: "Open final checklist"; Flags: postinstall shellexec skipifsilent
