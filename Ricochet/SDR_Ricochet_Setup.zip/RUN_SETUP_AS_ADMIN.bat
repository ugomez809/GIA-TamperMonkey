@echo off
setlocal
cd /d "%~dp0"

echo Running SDR Ricochet setup as admin...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File \"%CD%\setup.ps1\"' -Verb RunAs"
